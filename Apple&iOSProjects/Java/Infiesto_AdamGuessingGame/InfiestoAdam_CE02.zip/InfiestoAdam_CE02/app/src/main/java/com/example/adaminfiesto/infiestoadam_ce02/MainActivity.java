package com.example.adaminfiesto.infiestoadam_ce02;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;


//Adam S Infiesto
//Term C20180200
//MainActivity.Java

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "JAV1Project";
    //only doing number 0-9
    int [] possibleNum = {0,1,2,3,4,5,6,7,8,9};

    int colorValueR = 0;
    int colorValueG = 0;
    int colorValueB = 0;
    int userValues1 = 0;
    int userValues2 = 0;
    int userValues3 = 0;
    int userValues4 = 0;
    int gTurns = 4;
    //check to see if hitting
    int chickenDinner = 0;
    //need someplace  for answers?
    int aws1 = 0;
    int aws2 = 0;
    int aws3 = 0;
    int aws4 = 0;
    Toast daToast = null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        shuffleArray(possibleNum);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnGuess).setOnClickListener(daClicklisner1);


        //what answers are
         aws1 = possibleNum[0];
         aws2 = possibleNum[1];
         aws3 = possibleNum[2];
         aws4 = possibleNum[3];

        colorValueR = getColor(R.color.colorRed);
        colorValueG = getColor(R.color.colorGreen);
        colorValueB = getColor(R.color.colorBlue);

    }

    private final View.OnClickListener daClicklisner1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            EditText et1 = findViewById(R.id.editText_num1);
            EditText et2 = findViewById(R.id.editText_num2);
            EditText et3 = findViewById(R.id.editText_num3);
            EditText et4 = findViewById(R.id.editText_num4);

            //getting text
            String uInput1 = et1.getText().toString();
            String uInput2 = et2.getText().toString();
            String uInput3 = et3.getText().toString();
            String uInput4 = et4.getText().toString();

            if(daToast != null)
            {
                daToast.cancel();
            }

            if (!uInput1.isEmpty() | uInput2.isEmpty() | uInput3.isEmpty() | uInput4.isEmpty()) {
                try {

                    userValues1 = Integer.parseInt(uInput1);
                    userValues2 = Integer.parseInt(uInput2);
                    userValues3 = Integer.parseInt(uInput3);
                    userValues4 = Integer.parseInt(uInput4);
                }
                catch (NumberFormatException e)
                {
                    daToast = Toast.makeText(getApplicationContext(), "No Black Spaces", Toast.LENGTH_SHORT);
                    daToast.show();
                    return;
                }
                catch (Exception e)
                {
                    daToast = Toast.makeText(getApplicationContext(), "No Black Spaces", Toast.LENGTH_SHORT);
                    daToast.show();
                    Log.i(TAG, "selected number " + uInput1);
                    e.printStackTrace();
                    return;
                }


            }

            if (gTurns >= 0)
            {
                if (userValues1 > aws1)
                {
                    Log.i(TAG, "number is red " + aws1);
                    et1.setTextColor(colorValueR);

                }else if (userValues1 < aws1) {
                    et1.setTextColor(colorValueB);
                }else if (userValues1 == aws1)
                {
                    Log.i(TAG, "number is write " + aws1);
                    et1.setTextColor(colorValueG);
                    et1.setEnabled(false);
                    chickenDinner +=1;
                }

                if (userValues2 > aws2) {
                    Log.i(TAG, "number is red2 " + aws2);
                    et2.setTextColor(colorValueR);
                } else if (userValues2 < aws2) {
                    et2.setTextColor(colorValueB);
                } else if (userValues2 == aws2) {
                    Log.i(TAG, "number is write " + aws2);
                    et2.setTextColor(colorValueG);
                    et2.setEnabled(false);
                    chickenDinner +=1;
                }

                if (userValues3 > aws3) {
                    Log.i(TAG, "number is red3 " + aws3);
                    et3.setTextColor(colorValueR);
                } else if (userValues3 < aws3) {
                    et3.setTextColor(colorValueB);
                } else if (userValues3 == aws3) {
                    Log.i(TAG, "number is write " + aws3);
                    et3.setTextColor(colorValueG);
                    et3.setEnabled(false);
                    chickenDinner +=1;
                }

                if (userValues4 > aws4) {
                    Log.i(TAG, "number is red4 " + aws4);
                    et4.setTextColor(colorValueR);
                } else if (userValues4 < aws4) {
                    et4.setTextColor(colorValueB);
                } else if (userValues4 == aws4) {
                    Log.i(TAG, "number is write " + aws4);
                    et4.setTextColor(colorValueG);
                    et4.setEnabled(false);
                    chickenDinner +=1;
                }

                gTurns -= 1;
                String toast = Integer.toString(gTurns);
                Log.i(TAG, "Count"+chickenDinner);
                daToast = Toast.makeText(getApplicationContext(), toast, Toast.LENGTH_SHORT);
                daToast.show();
            }

            if(!et1.isEnabled()& !et2.isEnabled() & !et3.isEnabled() & !et4.isEnabled() )
            {
                findViewById(R.id.btnGuess).setOnClickListener(wonGame);
            }
            else if(gTurns == 1)
            {
                findViewById(R.id.btnGuess).setOnClickListener(gameOverL);
            }


        }

    };


    private final View.OnClickListener gameOverL = new View.OnClickListener() {
        @Override
        public void onClick(View v)
        {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle(R.string.dtitleL);
                builder.setMessage(R.string.dmsgL);

                builder.setPositiveButton(R.string.dbtnL, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        recreate();
                    }
                });

            builder.show();
        }
    };

    private final View.OnClickListener wonGame = new View.OnClickListener() {
        @Override
        public void onClick(View v)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
            builder.setTitle(R.string.dtitleW);
            builder.setMessage(R.string.dmsgW);
            builder.setPositiveButton(R.string.dbtnL, new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    recreate();
                }
            });
            builder.show();
        }
    };


    private static void shuffleArray(int[] ar) {

        Random someNumber = new Random();

        for (int i = ar.length - 1; i > 0; i--)
        {

            Log.d(TAG, "Turn Number: "+i);
            int index = someNumber.nextInt(i + 1);
            if (i == index)
            {
                ++i;
            }
            else
            {
                int a = ar[index];
                ar[index] = ar[i];
                ar[i] = a;
            }
        }
    }




}
